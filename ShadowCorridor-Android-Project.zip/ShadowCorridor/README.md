# ممر الظلال — Shadow Corridor

لعبة رعب عربية صغيرة تعمل داخل تطبيق Android عبر WebView. لا تطلب أذونات ولا تجمع بيانات.

## بناء APK عبر GitHub Actions
1. أنشئ مستودعاً جديداً على GitHub باسم `ShadowCorridor`.
2. ارفع كل محتويات هذا المجلد إلى المستودع، بحيث يظهر `app/` و`.github/` في الصفحة الرئيسية للمستودع.
3. افتح تبويب **Actions** واسمح بتشغيل workflows إذا طُلب منك.
4. افتح **Build Android APK** ثم اضغط **Run workflow**، أو ادفع commit جديداً.
5. بعد نجاح البناء، افتح نتيجة التشغيل وانزل إلى **Artifacts** ثم نزّل `ShadowCorridor-debug-apk`.
6. فك ضغط ملف Artifact، ثم ثبّت `app-debug.apk` على هاتف Android. قد يطلب الهاتف السماح بالتثبيت من مصدر التنزيل الذي استخدمته.

هذه نسخة Debug للتجربة، وليست إصداراً منشوراً على Google Play.
